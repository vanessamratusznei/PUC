
public class Tijolo extends Produtos {
	
	private static final long serialVersionUID = 1L;
	//6 furos, 8, furos, 21 furos...
	private int qtdeFuros;

	public Tijolo(String codigo, String nome, String fornecedor, int qtdeFuros) {
		super(codigo, nome, fornecedor);
		this.qtdeFuros = qtdeFuros;
		
	}

	public int getQtdeFuros() {
		return qtdeFuros;
	}

	public void setQtdeFuros(int qtdeFuros) {
		this.qtdeFuros = qtdeFuros;
	}
	
	public String toString() {
		String retorno = super.toString();
		retorno += "Furos: "     + this.qtdeFuros     + "\n";
		return retorno;
	}

}

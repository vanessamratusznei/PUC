import java.io.Serializable;

public abstract class Produtos implements Serializable{

	private static final long serialVersionUID = 1L;
	private String codigo;
	private String nome;
	private String fornecedor;
	
	public Produtos(String codigo, String nome, String fornecedor) {
		this.codigo = codigo;
		this.nome = nome;
		this.fornecedor = fornecedor;
	}

	public String toString() {
		String retorno = "";
		retorno += "Código: "     + this.codigo     + "\n";
		retorno += "Nome: "    + this.nome    + " \n";
		retorno += "Fornecedor: "     + this.fornecedor     + "\n";
		return retorno;
	}
	
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getFornecedor() {
		return fornecedor;
	}

	public void setFornecedor(String fornecedor) {
		this.fornecedor = fornecedor;
	}
	
	
	
}

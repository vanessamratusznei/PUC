
public class Cimento extends Produtos {
	
	private static final long serialVersionUID = 1L;
	//5kg, 25kg, 50kg
	private int sacoKilos;

	public Cimento(String codigo, String nome, String fornecedor, int sacoKilos) {
		super(codigo, nome, fornecedor);
		this.sacoKilos = sacoKilos;
		
	}

	public int getSacoKilos() {
		return sacoKilos;
	}

	public void setSacoKilos(int sacoKilos) {
		this.sacoKilos = sacoKilos;
	}
	
	public String toString() {
		String retorno = super.toString();
		retorno += "Saco: "     + this.sacoKilos     + " Kg\n";
		return retorno;
	}

}

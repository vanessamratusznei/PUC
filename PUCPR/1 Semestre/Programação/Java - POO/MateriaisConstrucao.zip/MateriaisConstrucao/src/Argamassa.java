
public class Argamassa extends Produtos {
	
	private static final long serialVersionUID = 1L;
	//AC1, AC2, AC3
	private String tipo;

	public Argamassa(String codigo, String nome, String fornecedor, String tipo) {
		super(codigo, nome, fornecedor);
		this.tipo = tipo;
		
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public String toString() {
		String retorno = super.toString();
		retorno += "Tipo: "     + this.tipo     + "\n";
		return retorno;
	}

}

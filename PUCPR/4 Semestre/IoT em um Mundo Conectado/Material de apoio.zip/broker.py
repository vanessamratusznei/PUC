mqtt_server = "broker.mqttdashboard.com"
mqtt_port = 1883
mqtt_user = ""
mqtt_password = ""
mqtt_client_id = "clientId-LaRNzQtOBj"